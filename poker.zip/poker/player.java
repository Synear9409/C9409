package poker;

import java.util.ArrayList;
import java.util.List;

public class player {
	public String name;
	public int id ;
	List<puke> pukes;
	public player(String name,int id) {
		this.name = name;
		this.id = id;
		this.pukes = new ArrayList<puke>();
	}
	public player() {
		
	}
}
