package poker;

public class puke {
	public String name;
	public int hua_id;
	public int su_id;
	
	public puke(String name,int hua_id,int su_id) {
		this.name = name;
		this.hua_id = hua_id;
		this.su_id = su_id;
	}
	public puke() {
		
	}
}
