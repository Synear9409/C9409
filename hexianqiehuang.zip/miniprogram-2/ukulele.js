// ukulele.js
Page({

  data: {
    src:'../image/c.png',
    btncss:{
    c  :'active',
    d: 'inactive',
    e: 'inactive',
    f: 'inactive',
    g: 'inactive',
    a: 'inactive',
    b: 'inactive'
    }
  },
  change:function(event){
    var binid = event.target.id;
    var imageFile = '../image/'+binid+'.png'
    var cssobj = this.data.btncss
    for(var key in cssobj){
      key == binid?cssobj[key] = "active": cssobj[key] = "inactive"
    }
    this.setData({
      src:imageFile,
      btncss:cssobj
    })
  }
})