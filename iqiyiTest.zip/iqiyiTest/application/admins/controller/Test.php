<?php
namespace app\admins\controller;
use think\Controller;
use Util\data\Sysdb;

class Test extends Controller
{
    public function index(){
        // $this->db = new Sysdb;
        // // $res = $this->db->table('admins')->field('id,username')->where(array('id' => 1))->item();
        // // $res1 = $this->db->table('admins')->item();
        // // var_dump($res1);
        // $res = $this->db->table('admins')->field('id,username')->lists();
        // dump($res);

        // echo '<hr>';
        // $res1 = $this->db->table('admins')->field('id,username')->cates('id');
        // dump($res1);


    }
}