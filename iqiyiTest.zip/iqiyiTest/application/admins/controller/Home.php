<?php
namespace app\admins\controller;
use think\Controller;
use Util\data\Sysdb;


//////后台首页
class Home extends BaseAdmin
{
    public function index(){
        $menus = false;
        $role = $this->db->table('admins_group')->where(array('gid'=> $this->_admin['gid']))->item();
        $site = $this->db->table('sites')->where(array('names' => 'site'))->item();
        $site && $site['values'] = json_decode($site['values']);
        if($role){
            $role['root'] = (isset($role['root']) && $role['root']) ? json_decode($role['root'],true) : [];
        }
        if($role['root']){
            $where = 'mid in ('.implode(',',$role['root']).') and ishidden = 0 and status = 0';
            $menus = $this->db->table('admins_menus')->where($where)->cates('mid');
            $menus && $menus = $this->gettreeitems($menus);
        }
        // dump($menus);exit; 
        return $this->fetch('index',['menus' => $menus,'role' => $role,'site' => $site]);
    }
    public function welcome(){
        return $this->fetch();
    }

    private function gettreeitems($items){
        $tree = array();
		foreach ($items as $item) {
			if(isset($items[$item['pid']])){
                $items[$item['pid']]['children'][] = &$items[$item['mid']];
			}else{
				$tree[] = &$items[$item['mid']];
			}
		}
		return $tree;
    }


}

































