<?php
namespace app\admins\controller;
use think\Controller;
use Util\data\Sysdb;

////管理员列表显示

class Admin extends BaseAdmin
{
    public function index(){
        $data['list'] = $this->db->table('admins')->lists();
        ////加载角色
        $data['group'] = $this->db->table('admins_group')->cates('gid');
        return $this->fetch('index',['data' => $data]);
    }
    /////从数据库查数据并返回前台
    public function add(){

        ///如果传过来的id大于0 则是编辑管理员 反之 为添加管理员(id = undefine)
        $id = (int)input('get.id');
        ////加载管理员
        $data['item'] =  $this->db->table('admins')->where(array('id' => $id))->item();
        ////加载角色
        $data['group'] = $this->db->table('admins_group')->cates('gid');
        return $this->fetch('add',['data' => $data]);
    }
    ////添加管理员方法
    public function save(){
        $id = (int)input('post.id');
        $username = trim(input('post.username'));
        $gid = (int)(input('post.gid'));
        $password = trim(input('post.password'));
        $truename = trim(input('post.truename'));
        $status = (int)(input('post.status'));
        

         ////格式化数据
         $arr = array(
            'username'=>$username,
            'password' =>$password,
            'truename' =>$truename,
            'gid' =>$gid,
            'status' =>$status
        );
        ////还有一种方法  不需要数据格式化
        // $data['username'] = trim(input('post.username'));
        // $data['gid'] = (int)(input('post.gid'));
        // $data['password'] = md5(trim(input('post.password')));
        // $data['truename'] = trim(input('post.truename'));
        // $data['status'] = (int)(input('post.status'));
        // $data['add_time'] = time();
        // 然后插入操作时 直接用$data

        
        ///如果密码不为空时就进行加密  ---因为编辑时 不修改密码时则指不对密码进行操作 则不需要再次加密
        if($password){
            ///这里指在添加操作的逻辑判断
            $password = md5($password);
        }
        ///因为TP5中update操作不做 则返回false
        $data = true;
        ///这里也是指在添加操作的逻辑判断
        if($id == 0){
            ////因为注册时间不能被编辑
            $date = time();
            $arr = array('add_time'=>$date);
            /////查询用户是否存在
            $isHasUser = $this->db->table('admins')->where(array('username' => $username))->item();
        if($isHasUser){
            exit(json_encode(['code' => 1,'msg' => '用户名已存在']));
        }    
            //将数据写入数据库
            $data = $this->db->table('admins')->field('*')->inserts($arr);
        }else{
            ////else即进行编辑的更新操作
            $this->db->table('admins')->where(array('id'=>$id))->update($arr);
        }
        
        if($data){
            exit(json_encode(['code' => 0,'msg' => '保存成功']));
        }else{
            exit(json_encode(['code' => 1,'msg' => '保存失败']));
        }
    }
    ////删除操作
    public function delete(){
        $id = (int)input('post.id');
        $res = $this->db->table('admins')->where(array('id' => $id))->delete();
        if($res){
            exit(json_encode(['code' => 0,'msg' => '删除成功!']));            
        }else{
            exit(json_encode(['code' => 1,'msg' => '删除失败!'])); 
        }
    }
}