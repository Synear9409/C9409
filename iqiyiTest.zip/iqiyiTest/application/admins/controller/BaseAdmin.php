<?php
namespace app\admins\controller;
use think\Controller;
use Util\data\Sysdb;

//////验证是否登录的控制器
class BaseAdmin extends Controller
{
    /////调用父类的构造函数
    public function __construct(){
        parent::__construct();
        $this->_admin = session('admin');
        if(!$this->_admin){
           $this->error('请先登录','/admins.php/admins/Account/login');         
        }
        $this->db = new Sysdb;
        $this->assign('admin',$this->_admin);
    }
    
}