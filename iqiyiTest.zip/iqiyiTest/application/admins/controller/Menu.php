<?php
namespace app\admins\controller;
use think\Controller;
use Util\data\Sysdb;

////菜单列表显示

class Menu extends BaseAdmin
{
    public function index(){
        $pid = (int)input('get.pid');
        $data['lists'] = $this->db->table('admins_menus')->where(array('pid' => $pid))->lists();

        ///返回上级菜单
        $backid = 0;
        ///如果pid大于0  则说明当前是子菜单   pid指子菜单id
        if($pid > 0){
            ///父级id
            $parent = $this->db->table('admins_menus')->field('pid')->where(array('mid' => $pid))->item();
            $backid = $parent['pid'];
        }
        return $this->fetch('index',['data' => $data,'backid' => $backid,'pid' => $pid]);
    }
    ///保存菜单方法
    public function save(){
        ///因为提交过去的是数组形式 TP5里就要用/a进行说明 这样后台就不会报错了
        $pid = (int)input('post.pid');
        $ords = input('post.ords/a');
        $titles = input('post.titles/a');
        $controllers = input('post.controllers/a');
        $methods = input('post.methods/a');
        $ishiddens = input('post.ishiddens/a');
        $status = input('post.status/a');

        foreach($ords as $key => $value){
            ////新增数据
            $data['pid'] = $pid;
            $data['ord'] = $value;
            $data['title'] = $titles[$key];
            $data['controller'] = $controllers[$key];
            $data['method'] = $methods[$key];
            $data['ishidden'] = isset($ishiddens[$key]) ? 1 : 0;
            $data['status'] = isset($status[$key]) ? 1 : 0;

            //$key=0 代表是菜单管理页面的最后一条数据  即将要进行添加的内容
            if($key == 0 && $data['title']){
                $this->db->table('admins_menus')->inserts($data);
            }
            if($key > 0){
                if($data['title']== '' && $data['controller']== '' && $data['method']== ''){
                    $this->db->table('admins_menus')->where(array('mid' => $key))->delete();
                }else{
                    $this->db->table('admins_menus')->where(array('mid' => $key))->update($data);
                }  
            }
        }
        exit(json_encode(['code' => 0,'msg' => '保存成功']));
    }

}