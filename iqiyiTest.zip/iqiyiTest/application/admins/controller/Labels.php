<?php
namespace app\admins\controller;
use think\Controller;
use Util\data\Sysdb;


//////标签管理
class Labels extends BaseAdmin
{
    ////频道管理
    public function channel(){
        $data['pageSize'] = 5;
        $data['page'] = max(1,(int)input('get.page'));
        $data['channel'] = $this->db->table('video_label')->where(array('flag'=>'channel'))->pages($data['pageSize']);
        return $this->fetch('channel',['data' => $data]);
    }

    ////资费管理
    public function charge(){
        $charge = $this->db->table('video_label')->where(array('flag'=>'charge'))->lists();
        return $this->fetch('charge',['data' => $charge]);
    }

    ///地区管理
    public function area(){
        $area = $this->db->table('video_label')->where(array('flag'=>'area'))->lists();
        return $this->fetch('area',['data' => $area]);
    }

    ///保存标签方法
    public function save(){
        ///因为提交过去的是数组形式 TP5里就要用/a进行说明 这样后台就不会报错了
        $flag = trim(input('post.flag'));
        $ords = input('post.ords/a');
        $titles = input('post.titles/a');
        $status = input('post.status/a');

        foreach($ords as $key => $value){
            ////新增数据
            $data['flag'] = $flag;
            $data['ord'] = $value;
            $data['title'] = $titles[$key];
            $data['status'] = isset($status[$key]) ? 1 : 0;

            //$key=0 代表是菜单管理页面的最后一条数据  即将要进行添加的内容
            if($key == 0 && $data['title']){
                $this->db->table('video_label')->inserts($data);
            }
            if($key > 0){
                if($data['title']== ''){
                    $this->db->table('video_label')->where(array('id' => $key))->delete();
                }else{
                    $this->db->table('video_label')->where(array('id' => $key))->update($data);
                }  
            }
        }
        exit(json_encode(['code' => 0,'msg' => '保存成功']));
    }


}