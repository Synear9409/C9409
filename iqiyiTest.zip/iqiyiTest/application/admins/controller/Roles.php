<?php
namespace app\admins\controller;
use think\Controller;
use Util\data\Sysdb;

////管理员列表显示

class Roles extends BaseAdmin
{
    public function index(){
        $data['roles'] = $this->db->table('admins_group')->lists();
        return $this->fetch('index',['data' => $data]);
    }

    /////角色添加
    public function add(){
        $gid = (int)input('get.gid');
        $role = $this->db->table('admins_group')->where(array('gid'=>$gid))->item();
        $role && $role['root'] && $role['root'] = json_decode($role['root']);
        $menus_list = $this->db->table('admins_menus')->where(array('status' => 0))->cates('mid');
        $menus = $this->gettreeitems($menus_list);
        $results = array();
        foreach($menus as $value){
            $value['children'] = isset($value['children'])?$this->formatMenus($value['children']):false;
            $results[] = $value;
        }
        return $this->fetch('add',['menus' => $results,'role'=>$role]);
    }

    ////将数据 树状化(PHP无限极分类  “引用算法”的知识)
    private function gettreeitems($items){
        $tree = array();
		foreach ($items as $item) {
			if(isset($items[$item['pid']])){
				$items[$item['pid']]['children'][] = &$items[$item['mid']];
			}else{
				$tree[] = &$items[$item['mid']];
			}
		}
		return $tree;
    }

    /////将无限下级菜单提取到 二级菜单 
    // 创建一个空数组 当传进的数组 没有children下标这一数据 存进res空数组中
    // 当某个数据有children下标时 将下标中里的数据存进 tem新的数组中 
    // 将$item['children']内容剔除(因为它还有子类  所以把它已经存进tem数组里 等待递归) 将$item(首次遍历的数据)存入$res中
    /// tem中的数组在检测是否有children 有的话 继续递归
    private function formatMenus($items,&$res = array()){
        foreach($items as $item){
            if(!isset($item['children'])){
                $res[] = $item;
            }else{
                $tem = $item['children'];
                unset($item['children']);  ////这个是将已经筛选过有子类的数据剔除  (主要是为了效率,不要这句代码结果也一样)
                $res[] = $item;
                $this->formatMenus($tem,$res);
            }
        }
        return $res;
    }
    ////角色保存方法
    public function save(){
        $gid = (int)input('post.gid');
        $data['title'] = input('post.title');
        $menus = input('post.menus/a');
        $menus && $data['root'] = json_encode(array_keys($menus));
        if($gid){
            $res = $this->db->table('admins_group')->where(array('gid' => $gid))->update($data);
        }else{
            $res = $this->db->table('admins_group')->inserts($data);
        }
        
        if($res){
            exit(json_encode(['code' => 0,'msg' => '保存成功']));
        }else{
            exit(json_encode(['code' => 1,'msg' => '保存失败']));
        }
    }
    ///角色删除方法
    public function deletes($gid){
        $gid = (int)input('post.gid');
        $res = $this->db->table('admins_group')->where(array('gid' => $gid))->delete();
        if($res){
            exit(json_encode(['code' => 0,'msg' => '删除成功']));
        }else{
            exit(json_encode(['code' => 1,'msg' => '删除失败']));
        }
    }
    
}