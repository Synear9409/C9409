<?php
namespace app\admins\controller;
use think\Controller;
use Util\data\Sysdb;

////幻灯片列表显示

class Slider extends BaseAdmin
{
    ////加载页面
    public function index(){
        $data = $this->db->table('slider')->where(array('type' => 0))->lists();
        return $this->fetch('index',['data' => $data]);
    }
    ////加载幻灯片add_first页面 并渲染数据
    public function add(){
        $id = (int)input('get.id');
        $data = $this->db->table('slider')->where(array('id' => $id))->item();
        return $this->fetch('add_first',['data' => $data]);
    }
    ////幻灯片信息删除
    public function delete(){
        $id = (int)input('post.id');
        $data = $this->db->table('slider')->where(array('id' => $id))->item();
        $address = ROOT_PATH.'public'.DS.$data['img']; 
        $res = $this->db->table('slider')->where(array('id' => $id))->delete();
        if($res){
            if(file_exists($address)){
                unlink($address);
            }
            exit(json_encode(['code' => 0,'msg' => '删除成功']));
        }else{
            exit(json_encode(['code' => 1,'msg' => '删除失败']));
        }
    }
    ////幻灯片信息的保存
    public function save(){
        $id = (int)input('post.id');
        $data['type'] = (int)input('post.type');
        $data['ord'] = (int)input('post.ord');
        $data['title'] = trim(input('post.title'));
        $data['url'] = trim(input('post.url'));
        $data['img'] = trim(input('post.img'));
        /////出去工作后 这里一定要在做输入数据的判断 /////因为前台的判断并不严谨
        if($data['title']=='' || $data['url']=='' || $data['img']==''){
            exit(json_encode(['code' => 1,'msg' => '输入数据不能为空']));
        }
        if($id){
            $this->db->table('slider')->where(array('id' => $id))->update($data);
        }else{
            $this->db->table('slider')->inserts($data);
        }
        exit(json_encode(['code' => 0,'msg' => '保存成功']));
    }

}