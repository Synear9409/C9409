<?php
namespace app\admins\controller;
use think\Controller;
use Util\data\Sysdb;


class Account extends Controller
{
    ////登录加载页面
    public function login(){
        return $this->fetch();
    }
    ////后台登录
    public function dologin(){
        $username = trim(input('post.username'));
        $password = trim(input('post.password'));
        $yzmcode = trim(input('post.yzmcode'));

    ///验证验证码是否正确
        if(!captcha_check($yzmcode)){
            exit(json_encode(array('code'=> 1,'msg'=>'验证码错误')));
        }
    /////验证用户
        $this->db = new Sysdb;
        $admin = $this->db->table('admins')->where(array('username' => $username))->item();
    ////验证用户名是否存在
        if(!$admin){
            exit(json_encode(array('code' => 1,'msg' => '用户名不存在')));
        }
    /////验证密码
        if($password != $admin['password']){
            exit(json_encode(array('code' => 1,'msg' => '密码错误')));
        }
    ////验证用户是否有权限
        if($admin['status'] == 1){
            exit(json_encode(array('code' => 1,'msg' => '用户已被禁用')));
        }
    /////验证成功 将数据存进session
        $adminsArr = array(
            'id' => $admin['id'],
            'username' => $admin['username'],
            'gid' => $admin['gid'],
            'status' => $admin['status'],
            'add_time' => $admin['add_time']
        );
        session('admin',$adminsArr);
        exit(json_encode(array('code' => 0,'msg' => '登录成功')));   
    }

    public function logout(){
        session('admin',null);
        exit(json_encode(['code' => 0,'msg' => '退出成功']));
    }
}
