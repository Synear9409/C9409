<?php
namespace app\admins\controller;
use think\Controller;
use Util\data\Sysdb;

////影片列表显示

class Video extends BaseAdmin
{
    public function index(){
        $data['pageSize'] = 10;
        //// 地址栏上获取当前是第几页 并传到前台配合layui分页的curr参数使用
        $data['page'] = max(1,(int)input('get.page'));
        $data['wd'] = trim(input('get.wd'));
        $where = array();
        $data['wd'] && $where = 'title like "%'.$data['wd'].'%"';
        $data['data'] = $this->db->table('video')->where($where)->order('id desc')->pages($data['pageSize']);

        $label_id = [];
        foreach($data['data']['lists'] as $item){
            !in_array($item['channel_id'],$label_id) && $label_id[] = $item['channel_id'];
            !in_array($item['charge_id'],$label_id) && $label_id[] = $item['charge_id'];
            !in_array($item['area_id'],$label_id) && $label_id[] = $item['area_id'];
        }
        $label_id && $data['labels'] = $this->db->table('video_label')->where('id in('.implode(',',$label_id).')')->cates('id');
        return $this->fetch('index',['data' => $data]);
    }

    ////影片添加
    public function add(){
        $data['channel'] = $this->db->table('video_label')->where(array('flag' => 'channel'))->lists();
        $data['charge'] = $this->db->table('video_label')->where(array('flag' => 'charge'))->lists();
        $data['area'] = $this->db->table('video_label')->where(array('flag' => 'area'))->lists();
        $id = (int)input('get.id');
        $data['item'] = $this->db->table('video')->where(array('id' => $id))->item();
        return $this->fetch('add',['data' => $data]);
    }

    /////图片上传方法
    public function upload_img(){
        $file = request()->file('file');
        if($file == null){
            exit(json_encode(['code' =>1,'msg' => '文件不存在']));
        }
        ///设置上传路径 DS代表斜杆'/' ROOT_PATH 代表的是public上一级目录 例如：D:\PHPStudy\php\WWW\tp5\ 目录下，包括app、public 等等  它是系统常量
        $info = $file->move(ROOT_PATH.'public'.DS.'uploads');
        ////取文件扩展名  
        $ext = ($info->getExtension());
        ///设置允许的后缀
        if(!in_array($ext,array('jpg','png','jpeg','gif'))){
            exit(json_encode(['code' =>1,'msg' => '文件格式不支持']));
        }
        //// getSaveName()---获取保存的文件名    ///将反斜杠“\” 替换成/
        $getSaveName=str_replace("\\","/",$info->getSaveName());
        $img = '/uploads/'.$getSaveName;
        exit(json_encode(['code' => 0,'msg' => $img]));
    }
    ////影片信息保存的方法
    public function save(){
        $id = (int)input('post.id');
        $data['title'] = trim(input('post.title'));
        $data['channel_id'] = (int)input('post.channel_id');
        $data['charge_id'] = (int)input('post.charge_id');
        $data['area_id'] = (int)input('post.area_id');
        $data['img'] = trim(input('post.img'));
        $data['url'] = trim(input('post.url'));
        $data['keywords'] = trim(input('post.keywords'));
        $data['desc'] = trim(input('post.desc'));
        $data['status'] = (int)input('post.status');     
        if($id){
            $this->db->table('video')->where(array('id' => $id))->update($data);
        }else{
            $data['add_time'] = time();
            $this->db->table('video')->inserts($data);
        }
        exit(json_encode(['code' => 0,'msg' => '保存成功']));
    }
    ////影片信息的删除
    public function delete(){
        $id = (int)input('post.id');
        $data = $this->db->table('video')->where(array('id' => $id))->item();
        $address = ROOT_PATH.'public'.DS.$data['img']; 
        $res = $this->db->table('video')->where(array('id' => $id))->delete();
        if($res){
            if(file_exists($address)){
                unlink($address);
            }
            exit(json_encode(['code' => 0,'msg' => '删除成功']));
        }else{
            exit(json_encode(['code' => 1,'msg' => '删除失败']));
        }
    }
}